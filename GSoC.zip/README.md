Independent-Projects
====================

 Personal endevours intro the wonderful world of Computer Science
 Here you will find:
 
 1. My Google Summer of Code Proposal and proof-of-concept game, made using the pysoy engine. You may download pysoy, which is needed in running the game, here: http://www.pysoy.org/
